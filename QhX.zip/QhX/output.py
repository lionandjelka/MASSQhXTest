import pandas as pd
import numpy as np
import math


def classify_periods(detected_periods):
    """
    # Example usage
   	classified_periods = classify_periods(detected_periods)
   	print(classified_periods)
    
    Classify detected periods by calculating IoU and other metrics for each quasar ID.
    This function processes the structured data from the `process1` function and 
    classifies periods based on the criteria provided. It computes Intersection Over Union (IoU)
    and other relevant metrics for each quasar ID based on detected periods in different band pairs.

    Parameters:
    detected_periods (list of dict): List of dictionaries containing detected period data.

    Returns:
    pd.DataFrame: DataFrame containing the classification results.
    """

    # Convert list of dictionaries to DataFrame
    df = pd.DataFrame(detected_periods)

    # Function to calculate IoU for a pair of detected periods
    def calculate_iou(radius1, radius2, distance):
        """
        Calculates the Intersection over Union (IoU) for two circles given their radii and the distance between their centers.

        Parameters:
        radius1 (float): Radius of the first circle.
        radius2 (float): Radius of the second circle.
        distance (float): Distance between the centers of the two circles.

        Returns:
        float: IoU value.
        """
        if distance > (radius1 + radius2):
            return 0
        elif distance <= abs(radius1 - radius2):
            return 1
        else:
            area1 = math.pi * radius1**2
            area2 = math.pi * radius2**2
            d = distance

            # Calculate intersection area
            part1 = math.acos((radius1**2 + d**2 - radius2**2) / (2 * radius1 * d))
            part2 = math.acos((radius2**2 + d**2 - radius1**2) / (2 * radius2 * d))
            intersection = part1 * radius1**2 + part2 * radius2**2 - 0.5 * (radius1**2 * math.sin(2 * part1) + radius2**2 * math.sin(2 * part2))

            union = area1 + area2 - intersection
            return intersection / union

    # Initialize output DataFrame
    output_df = pd.DataFrame(columns=['name', 'm3', 'm4', 'm5', 'm6', 'm7_1', 'm7_2', 'iou'])

    # Process each unique quasar ID
    for name in df['objectid'].unique():
        quasar_data = df[df['objectid'] == name]

        for i in range(len(quasar_data)):
            for j in range(i + 1, len(quasar_data)):
                row_i = quasar_data.iloc[i]
                row_j = quasar_data.iloc[j]

                # Calculate relative difference in detected periods
                if abs(row_i['period'] - row_j['period']) / row_i['period'] <= 0.1:
                    # Calculate IoU
                    radius_i = (row_i['upper_error'] + row_i['lower_error']) / 2
                    radius_j = (row_j['upper_error'] + row_j['lower_error']) / 2
                    distance = abs(row_i['period'] - row_j['period'])
                    iou = calculate_iou(radius_i, radius_j, distance)

                    # Append the results to the output DataFrame
                    output_df = output_df.append({
                        'name': name,
                        'm3': row_i['period'],
                        'm4': row_i['lower_error'],
                        'm5': row_i['upper_error'],
                        'm6': row_i['significance'],
                        'm7_1': row_i['label'],
                        'm7_2': row_j['label'],
                        'iou': iou
                    }, ignore_index=True)

    return output_df


def classify_period(row):
    """
	# Example usage
	classified_periods = classify_periods(detected_periods)

	# Apply the classification function to each row of the DataFrame
	classified_periods['classification'] = classified_periods.apply(classify_period, axis=1)

	print(classified_periods)
    Classify the detected period as 'reliable', 'medium reliable', 'poor', or 'NAN'
    based on the significance of the detected period, the relative lower and upper errors,
    and the IoU of the error circles.

    Parameters:
    row (pd.Series): A row from the DataFrame containing detected period data.

    Returns:
    str: Classification of the period ('reliable', 'medium reliable', 'poor', 'NAN').
    """
    # Check for NaN values
    if row.isna().any():
        return 'NAN'

    # Calculate relative errors
    rel_error_lower = row['m4'] / row['m3']
    rel_error_upper = row['m5'] / row['m3']

    # Classify based on criteria
    if row['m6'] >= 0.99 and rel_error_lower <= 0.1 and rel_error_upper <= 0.1 and row['iou'] >= 0.99:
        return 'reliable'
    elif 0.5 <= row['m6'] < 0.99 and 0.1 < rel_error_lower <= 0.3 and 0.1 < rel_error_upper <= 0.3 and 0.8 <= row['iou'] < 0.99:
        return 'medium reliable'
    else:
        return 'poor'

